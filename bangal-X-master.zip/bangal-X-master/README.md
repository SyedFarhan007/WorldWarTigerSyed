# bangal-X
pkg update

pkg upgrade

pkg install git

pkg install python2

git clone https://github.com/Tech-abm/bangal-X

cd bangal-X

chmod +x *

python2 abm-X.py

Username : abm01

Password : abm01





